function whoIsWinner(piecesPositionList){
    //return "Red", "Yellow" or "Draw"
    let board = {
        A : [],
        B : [],
        C : [],
        D : [],
        E : [],
        F : [],
        G : []
    }
    const indexes = ['A','B','C','D','E','F','G'];
    for(i=0; i<piecesPositionList.length; i++){
        board[piecesPositionList[i][0]].push(piecesPositionList[i].slice(2))
    }
    // let arr = [];
    // for(l = 0; l < board.indexes.length; l++){

    //     for(t=0; t<=l; t++){
    //         board[board.indexes[l]].unshift(0)
    //     }
    //     arr.push(board[board.indexes[l]][5])
    //     console.log(arr)
    // }
    console.log(board)
    function checkDia(col){
        let offset = 0;
        let count = 0;
        for(i=0; i<4; i++){
            if(board[indexes[col]][0] === board[indexes[i]][i + offset]){
                count += 1;
            }else{
                offset += 1;
                count = 0;
            }
        }
        
        console.log(count)
        console.log(board[indexes[col]])
    }
    console.log(checkDia(0))
}
console.log(whoIsWinner(['A_Red',
    'B_Yellow',
    'A_Red',
    'C_Yellow',
    'A_Red',
    'C_Yellow',
    'B_Red',
    'D_Yellow',
    'C_Red',
    'D_Yellow',
    'D_Red',
    'E_Yellow',
    'D_Red'
]))

// console.log(whoIsWinner(["C_Yellow",
// "E_Red",
// "G_Yellow",
// "B_Red",
// "D_Yellow",
// "B_Red",
// "B_Yellow",
// "G_Red",
// "C_Yellow",
// "C_Red",
// "D_Yellow",
// "F_Red",
// "E_Yellow",
// "A_Red",
// "A_Yellow",
// "G_Red",
// "A_Yellow",
// "F_Red",
// "F_Yellow",
// "D_Red",
// "B_Yellow",
// "E_Red",
// "D_Yellow",
// "A_Red",
// "G_Yellow",
// "D_Red",
// "D_Yellow",
// "C_Red"])) // yellow