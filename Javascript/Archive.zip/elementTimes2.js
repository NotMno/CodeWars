function maps(x){
    return x.map(ele => ele * 2)
}
console.log(maps([1,2,3,4,5,6]))